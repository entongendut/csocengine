package io.securecodebox.persistence;

public enum DefectDojoMetaFields {
    DEFECT_DOJO_USER
}
