package io.securecodebox.persistence.elasticsearch;

public class ElasticSearchPersistenceProviderTest {
}
