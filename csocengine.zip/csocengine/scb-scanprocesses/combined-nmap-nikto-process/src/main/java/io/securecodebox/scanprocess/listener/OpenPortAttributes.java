package io.securecodebox.scanprocess.listener;

public enum OpenPortAttributes {
    hostname, port, service
}
