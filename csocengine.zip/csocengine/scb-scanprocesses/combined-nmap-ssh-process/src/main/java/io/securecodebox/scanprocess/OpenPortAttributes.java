package io.securecodebox.scanprocess;

public enum OpenPortAttributes {
    ip_address, port, service
}
