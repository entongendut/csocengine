package io.securecodebox.scanprocess.zap.constants;

public enum ZapProcessVariables {
    SKIP_SPIDER;
}
