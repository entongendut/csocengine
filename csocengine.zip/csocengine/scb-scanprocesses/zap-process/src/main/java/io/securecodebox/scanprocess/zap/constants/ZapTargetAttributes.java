package io.securecodebox.scanprocess.zap.constants;

public enum ZapTargetAttributes {
    ZAP_SITEMAP;
}
