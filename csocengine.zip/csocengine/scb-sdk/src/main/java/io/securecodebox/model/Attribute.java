package io.securecodebox.model;

public class Attribute {

    private String from;
    private String to;

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }
}
